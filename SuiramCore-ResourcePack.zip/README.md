# カスタムアイテム4種 リソースパック（Minecraft Java版）

参考ビジュアル資料（キャラクター名不使用のオリジナル創作物）を基に、
512x512の高精細・背景透過アイコンとして作成したカスタムアイテム4種です。

## 収録アイテム

| アイテム | ファイル名 | デザイン |
|---|---|---|
| 石化装置 | petrification_device | 3本のリングが絡み合う球状の金属装置。鱗状の鎧パネルとシアンの発光回路 |
| ダイヤモンド電池 | diamond_battery | 六角錐型のクリスタル。中心から6頂点へ伸びる発光稜線、内部に結晶ひび模様 |
| スタンドの矢 | stand_arrow | 銀の刃に金の甲虫型装飾が乗り、中央に赤い宝石が輝く穂先 |
| 空のディスク | sky_disc | 銀色のレコード盤状の円盤。同心円のブラッシュドメタル質感と「DISC」の刻印 |

いずれも `item/generated`（平面アイコン型）のモデルです。石化装置・スタンドの矢は
絡み合うリングや有機的な装飾など、Minecraftの直方体ベースモデルでは再現不可能な
複雑形状のため、精密に描いたアイコンテクスチャで表現しています。

## ファイル構成
```
assets/minecraft/
├── items/                 1.21.4+ 新アイテム定義
│   ├── petrification_device.json
│   ├── diamond_battery.json
│   ├── stand_arrow.json
│   └── sky_disc.json
├── models/item/            item/generated モデル本体
│   ├── petrification_device.json
│   ├── diamond_battery.json
│   ├── stand_arrow.json
│   └── sky_disc.json
└── textures/item/          512x512 背景透過アイコン
    ├── petrification_device.png
    ├── diamond_battery.png
    ├── stand_arrow.png
    └── sky_disc.png
```

## 導入方法

### 1. リソースパックとして配置
このフォルダ（またはzip化したもの）を `.minecraft/resourcepacks/` に置き、
ゲーム内オプション→リソースパックで有効化します。

### 2. アイテムに紐付ける

**1.21.4以降（新アイテムモデルシステム、推奨）**

ベースアイテム（例: 紙 = paper）に `minecraft:select` で分岐させます。
`assets/minecraft/items/paper.json` を作成・編集:
```json
{
  "model": {
    "type": "minecraft:select",
    "property": "minecraft:custom_model_data",
    "cases": [
      { "when": "petrification_device", "model": { "type": "minecraft:model", "model": "minecraft:item/petrification_device" } },
      { "when": "diamond_battery",       "model": { "type": "minecraft:model", "model": "minecraft:item/diamond_battery" } },
      { "when": "stand_arrow",           "model": { "type": "minecraft:model", "model": "minecraft:item/stand_arrow" } },
      { "when": "sky_disc",              "model": { "type": "minecraft:model", "model": "minecraft:item/sky_disc" } }
    ],
    "fallback": { "type": "minecraft:model", "model": "minecraft:item/paper" }
  }
}
```
コマンド例:
```
/give @p paper[custom_model_data={strings:["petrification_device"]}]
/give @p paper[custom_model_data={strings:["diamond_battery"]}]
/give @p paper[custom_model_data={strings:["stand_arrow"]}]
/give @p paper[custom_model_data={strings:["sky_disc"]}]
```

**1.21.3以前（custom_model_data 数値方式）**

ベースアイテムのモデルJSONに overrides を追加:
```json
{
  "parent": "minecraft:item/generated",
  "textures": { "layer0": "minecraft:item/paper" },
  "overrides": [
    { "predicate": { "custom_model_data": 3001 }, "model": "minecraft:item/petrification_device" },
    { "predicate": { "custom_model_data": 3002 }, "model": "minecraft:item/diamond_battery" },
    { "predicate": { "custom_model_data": 3003 }, "model": "minecraft:item/stand_arrow" },
    { "predicate": { "custom_model_data": 3004 }, "model": "minecraft:item/sky_disc" }
  ]
}
```
コマンド例: `/give @p paper{CustomModelData:3001}`

## 制作メモ
- 石化装置は、3本のトーラス(円環)をロドリゲスの回転公式で正確に3回対称配置し、
  法線ベクトルから陰影・スペキュラハイライトを計算する疑似3Dレンダリングで作成。
  表面の鱗パネルは規則的な格子状の継ぎ目として描画し、継ぎ目の一部だけを
  シアン発光させることで「金属地にうっすら回路が走る」質感を再現しています。
- ダイヤモンド電池は、六角錐（六角形の底面＋中央の頂点に向かう6枚の三角ファセット）
  を幾何学的に構築し、稜線を発光ラインとして強調しています。
- スタンドの矢は、涙滴型のシルエット関数（先端が鋭く、下部が広い非対称カーブ）を
  ベースに、左右の切れ込み(ノッチ)、鱗模様、金の甲虫型装飾（頭部・6本脚・甲羅・
  赤い宝石）を要素ごとに手動配置しています。
- 空のディスクは、楕円+弧状の側面で厚みを表現し、同心円の溝と放射状のブラッシュド
  メタルノイズをnumpyで計算、中心の穴とDISC刻印を追加しています。
- 全テクスチャとも背景は完全透過（アルファ0）で書き出し済みです。

## カスタマイズ
`textures/item/` 内のPNG（すべて512x512）を差し替えるだけで見た目を変更できます。
